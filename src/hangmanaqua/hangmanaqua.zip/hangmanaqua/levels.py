level = 1

def update_level():
    """Returns the next level."""
    global level
    level = level + 1
    return level